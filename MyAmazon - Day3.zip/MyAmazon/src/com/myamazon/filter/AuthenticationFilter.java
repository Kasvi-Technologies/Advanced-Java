package com.myamazon.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AuthenticationFilter implements Filter{

	
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	public void doFilter(ServletRequest arg0, ServletResponse arg1, 
							FilterChain chain)
			throws IOException, ServletException {
		
		//signed in or not
		HttpServletRequest request = (HttpServletRequest)arg0;
		HttpServletResponse response = (HttpServletResponse)arg1;
		HttpSession session  = request.getSession();
		
		String uri = request.getRequestURI();
		System.out.println("uri:" + uri);
		if(session.getAttribute("userLoggedIn") != null
				|| (uri.contains("sample.jsp") ||  uri.contains("register")|| uri.contains("login.jsp") || uri.contains("loginServlet") 
						|| "/myamazon".equals(uri) || "/myamazon/".equals(uri) )){
			//user already logged in and so continue..
			chain.doFilter(arg0, arg1);
			return;
		} else {
			//user not logged in and so redirect to login page 
			//you can use RequestDisptacher also to transfer the control to login page.
			
			//will create the fresh request and response
			//due to the new request all existing information is not available in the next page
			
			//it executes in the browser
			
			// 2. you can transfer control to another domain pages
			response.sendRedirect("login.jsp");
			return;
			
		}
		
	}

	public void init(FilterConfig config) throws ServletException {
		// TODO Auto-generated method stub
		
	}

}
