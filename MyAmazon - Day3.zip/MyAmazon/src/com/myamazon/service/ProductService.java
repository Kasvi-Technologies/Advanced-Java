package com.myamazon.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.myamazon.beans.Product;
import com.myamazon.dao.ProductDAO;

public class ProductService {
		private ProductDAO productDAo ;

	public List<Product> fetchProductListBasedOnType(HttpServletRequest request, String type) {
		//Business logic
		return productDAo.fetchProductListBasedOnType(request, type);
	}
	
}
