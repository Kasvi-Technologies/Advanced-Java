package com.myamazon.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import com.myamazon.beans.Product;

public class ProductDAO {

	public List<Product> fetchProductListBasedOnType(HttpServletRequest request, String type) {
		
		List<Product>  productList = new ArrayList<Product>();
		ServletContext context = request.getServletContext();
		
		String driverName = context.getInitParameter("driverName");
		String dburl =  context.getInitParameter("dburl");
		String dbUsername =  context.getInitParameter("username");
		String dbPassword = context.getInitParameter("password");
		
		try {
			Class.forName(driverName);
			Connection con = 
						DriverManager.getConnection(dburl , dbUsername , dbPassword);
			Statement st = con.createStatement();
			String query = "select * from product where type = '"+type+"'";
			
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				Product product = new Product();
				
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				double price = rs.getDouble("price");
				
				product.setId(id);
				product.setName(name);
				product.setDescription(description);
				product.setPrice(price);
				product.setType(type);
				
				productList.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return productList;
	}
	
}
