package com.myamazon.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myamazon.beans.Product;
import com.myamazon.service.ProductService;

public class ProductListServlet extends HttpServlet {
	
	private ProductService productService ;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		//Business logic to fetch products based on type parameter
		String type = request.getParameter("type");
		System.out.println("selected type:" + type);		
		
		//fetch products based on type		
		List<Product> productList = 
									productService.fetchProductListBasedOnType(request, type);	
		
		request.setAttribute("productList", productList);
		
		//transfer control to productListDisplay.jsp
		
		RequestDispatcher rd = request.getRequestDispatcher("productListDisplay.jsp");
		rd.forward(request, response);
		return;
	}
	
	
	
	
	
	
	
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doGet(request, response);
	}
}
