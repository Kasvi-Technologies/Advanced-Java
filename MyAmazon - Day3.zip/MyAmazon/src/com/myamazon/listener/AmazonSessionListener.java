package com.myamazon.listener;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class AmazonSessionListener implements 
					HttpSessionListener{

	public void sessionCreated(HttpSessionEvent event) {
		// TODO Auto-generated method stub
		
		//Business logic
		HttpSession session = event.getSession();
		System.out.println("Session created with id....." + session.getId());
		System.out.println("Session creation time....." + session.getCreationTime());
	}

	public void sessionDestroyed(HttpSessionEvent event) {
		// TODO Auto-generated method stub
		System.out.println("Session destroyed which has id of ....." + event.getSession().getId());
	}

}
