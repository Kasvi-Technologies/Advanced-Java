package com.myamazon.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {
	
	public boolean validateUser(HttpServletRequest request , String userName, String password){
		boolean found = false;
		
		ServletContext context = request.getServletContext();
		
		String driverName = context.getInitParameter("driverName");
		String dburl =  context.getInitParameter("dburl");
		String dbUsername =  context.getInitParameter("username");
		String dbPassword = context.getInitParameter("password");
	
		try {
			Class.forName(driverName);
			Connection con = 
						DriverManager.getConnection(dburl , dbUsername , dbPassword);
			Statement st = con.createStatement();
			String query = "select * from user "
					+ "where username = '" + userName + "' and password='"+password+"'";
			System.out.println("query:" + query);
			ResultSet rs = st.executeQuery(query);
			if(rs.next()){
				System.out.println("User found in db...");
				found = true;
			} else {
				System.out.println("User does not exists.....");
			}
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
		return found;
		
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		System.out.println("in side doGet()");
		//retrieve the paramenters from login page
		
		//Retrieve Context parameters......
		ServletContext context = request.getServletContext();
		System.out.println("DriverName:" + context.getInitParameter("driverName"));
		System.out.println("DBURL:" + context.getInitParameter("dburl"));
		System.out.println("Username:" + context.getInitParameter("username"));
		System.out.println("password:" + context.getInitParameter("password"));
		
		context.setAttribute("message", "context message");
		
		
		
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		
		System.out.println(userName + " = " + password);
		
		HttpSession session = request.getSession(); 
		// user information will be available to all requests in that particular browser sessions
		
		//We need to fire a database request to validate user exists in db or not..
		//business logic
		
		String result = "";
		
		//fire a database request 
		boolean found = validateUser(request, userName, password);
		
		//if("Admin".equals(userName) && "password".equals(password)){
		if(found == true){
			session.setAttribute("userLoggedIn", "true");
			result = "displayProducts.html";
			
			//Will create a cookie and store the loggedin information in the cookie
			// cookie - store the information in client machine and available to that browser
			
			Cookie userNamecookie = new Cookie("username" , userName);
			Cookie passwordcookie = new Cookie("password" , password);
			
			userNamecookie.setMaxAge(30 * 60); // seconds
			passwordcookie.setMaxAge(30 * 60); // seconds
			//30 mins
			
			response.addCookie(userNamecookie);
			response.addCookie(passwordcookie);
			
			
		} else {
			String message = "Invalid Login!!! Please try Again.";
			request.setAttribute("loginErrorMessage", message);
			result = "login.jsp";
		}
		
		//transfer control from one page to another
		
		//it will transfer current request and response
		
		RequestDispatcher rd = request.getRequestDispatcher(result);
		rd.forward(request, response);
		return;
	}
	
	public void doPost(HttpServletRequest request, 	HttpServletResponse response) throws ServletException, IOException{
		System.out.println("in side doPost()");
		doGet(request, response);
	}

}
