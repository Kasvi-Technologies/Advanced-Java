package com.myamazon.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.PreparedStatement;

public class RegisterServlet extends HttpServlet {
	
	public void insertIntoDB(HttpServletRequest request, String userName, String  password, 
			String emailId, String  gender, String hobbiesStr) {
		
		ServletContext context = request.getServletContext();
		
		String driverName = context.getInitParameter("driverName");
		String dburl =  context.getInitParameter("dburl");
		String dbUsername =  context.getInitParameter("username");
		String dbPassword = context.getInitParameter("password");
	
		try {
			Class.forName(driverName);
			Connection con = 
						DriverManager.getConnection(dburl , dbUsername , dbPassword);
			
			String query = "insert into user (username, password, emailid, gender, hobbies) values"
					+ " (?, ?, ?,?,?) ";
			
			PreparedStatement pst = con.prepareStatement(query);
			
			System.out.println("query:" + query);
			pst.setString(1, userName);
			pst.setString(2, password);
			pst.setString(3, emailId);
			pst.setString(4, gender);
			pst.setString(5, hobbiesStr);
			
			pst.executeUpdate();
			
			
		} catch (Exception e){
			e.printStackTrace();
		}
		
	
		
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		System.out.println("in side doGet()");
		//retrieve the paramenters from login page
		
		String userName = request.getParameter("userName");
		String emailId = request.getParameter("emailid");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String[] hobbies = request.getParameterValues("hobbies");
		
		String hobbiesStr = "";
		for (String str: hobbies){
			if("".equals(hobbiesStr))
				hobbiesStr = str ;
			else
				hobbiesStr = hobbiesStr + " , " + str ;
		}
		
		System.out.println(userName + " = " + password);
		System.out.println(emailId + " = " + gender);
		System.out.println(hobbiesStr);
		
		
		insertIntoDB(request, userName, password, emailId, gender,hobbiesStr);
		
		String result = "login.jsp";
		
		
		//transfer control from one page to another
		
		RequestDispatcher rd = request.getRequestDispatcher(result);
		rd.forward(request, response);
		return;
	}
	
	public void doPost(HttpServletRequest request, 	HttpServletResponse response) throws ServletException, IOException{
		System.out.println("in side doPost()");
		doGet(request, response);
	}

}
