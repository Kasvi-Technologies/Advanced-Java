package com.myamazon.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.myamazon.beans.Product;

public class ProductListServlet extends HttpServlet {

	public List<Product> fetchProductListBasedOnType(HttpServletRequest request, String type) {
		
		List<Product>  productList = new ArrayList<Product>();
		ServletContext context = request.getServletContext();
		
		String driverName = context.getInitParameter("driverName");
		String dburl =  context.getInitParameter("dburl");
		String dbUsername =  context.getInitParameter("username");
		String dbPassword = context.getInitParameter("password");
		
		try {
			Class.forName(driverName);
			Connection con = 
						DriverManager.getConnection(dburl , dbUsername , dbPassword);
			Statement st = con.createStatement();
			String query = "select * from product where type = '"+type+"'";
			
			ResultSet rs = st.executeQuery(query);
			while (rs.next()) {
				Product product = new Product();
				
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String description = rs.getString("description");
				double price = rs.getDouble("price");
				
				product.setId(id);
				product.setName(name);
				product.setDescription(description);
				product.setPrice(price);
				product.setType(type);
				
				productList.add(product);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return productList;
	}
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		//Business logic to fetch products based on type parameter
		String type = request.getParameter("type");
		System.out.println("selected type:" + type);		
		
		//fetch products based on type		
		List<Product> productList = fetchProductListBasedOnType(request, type);	
		
		request.setAttribute("productList", productList);
		
		//transfer control to productListDisplay.jsp
		
		RequestDispatcher rd = request.getRequestDispatcher("productListDisplay.jsp");
		rd.forward(request, response);
		return;
	}
	
	
	
	
	
	
	
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		doGet(request, response);
	}
}
